#include <windows.h> 

#define FUNC __declspec(dllimport) __stdcall

HANDLE FUNC OpenHidHandle(unsigned short vendor_id, unsigned short product_id);
void FUNC ReadReport(HANDLE handle,unsigned char *InputReport,int *len);
void FUNC WriteReport(HANDLE handle,unsigned char *OutputReport, int *len);
void FUNC CloseHidHandle(HANDLE handle);
