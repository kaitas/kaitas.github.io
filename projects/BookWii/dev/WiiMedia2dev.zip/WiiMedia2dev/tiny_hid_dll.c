#include <windows.h> 
#include <string.h> 
#include <setupapi.h> 
#include "hidsdi.h"

HANDLE __declspec(dllexport) __stdcall OpenHidHandle(unsigned short vendor_id, unsigned short product_id);
void __declspec(dllexport) __stdcall ReadReport(HANDLE handle,unsigned char *InputReport,int *len);
void __declspec(dllexport) __stdcall WriteReport(HANDLE handle,unsigned char *OutputReport, int *len);
void __declspec(dllexport) __stdcall CloseHidHandle(HANDLE handle);


NTSTATUS GetDeviceCapabilities( HANDLE );
void PrepareForOverlappedTransfer( void );

HIDP_CAPS Capabilities;

NTSTATUS GetDeviceCapabilities( HANDLE hRsDevHandle ) {
	PHIDP_PREPARSED_DATA PreparsedData;
	NTSTATUS Result = HIDP_STATUS_INVALID_PREPARSED_DATA;

	if ( HidD_GetPreparsedData( hRsDevHandle, &PreparsedData ) ) {
		Result = HidP_GetCaps( PreparsedData, &Capabilities );
		HidD_FreePreparsedData( PreparsedData );
	}

	return Result;
}


HANDLE __declspec(dllexport) __stdcall OpenHidHandle(unsigned short vendor_id, unsigned short product_id)
{
	HANDLE hDevHandle;
	GUID HidGuid;
	HDEVINFO hDevInfo = 0;
	BOOL bDevDetected = FALSE; 
	SP_DEVICE_INTERFACE_DATA devInfoData;
	PSP_DEVICE_INTERFACE_DETAIL_DATA detailData = NULL;
	HIDD_ATTRIBUTES Attributes;
	BOOL LastDevice = FALSE;
	DWORD MemberIndex = 0;
	LONG Result;
	DWORD Required;
	DWORD Length = 0;

	hDevHandle = INVALID_HANDLE_VALUE;

	HidD_GetHidGuid( &HidGuid );
	hDevInfo = SetupDiGetClassDevs( (LPGUID)&HidGuid, NULL, (HWND)NULL, DIGCF_INTERFACEDEVICE | DIGCF_PRESENT );

	if ( 0 == hDevInfo ) return INVALID_HANDLE_VALUE;

	do {
		bDevDetected=FALSE;
		devInfoData.cbSize = sizeof(SP_DEVICE_INTERFACE_DATA);
		Result = SetupDiEnumDeviceInterfaces 
			(hDevInfo, 
			NULL, 
			&HidGuid, 
			MemberIndex, 
			&devInfoData);

		if (Result != 0) {
			Result = SetupDiGetDeviceInterfaceDetail 
				(hDevInfo, 
				&devInfoData, 
				NULL, 
				0, 
				&Length, 
				NULL);

			detailData = (PSP_DEVICE_INTERFACE_DETAIL_DATA)malloc(Length);
			detailData -> cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);

			Result = SetupDiGetDeviceInterfaceDetail 
				(hDevInfo, 
				&devInfoData, 
				detailData, 
				Length, 
				&Required, 
				NULL);

			hDevHandle = CreateFile 
				(detailData->DevicePath, 
				GENERIC_READ|GENERIC_WRITE, 
				FILE_SHARE_READ|FILE_SHARE_WRITE, 
				(LPSECURITY_ATTRIBUTES)NULL,
				OPEN_EXISTING, 
				0, 
				NULL);

			bDevDetected = FALSE;
			Attributes.Size = sizeof(Attributes);

			if ( HidD_GetAttributes( hDevHandle, &Attributes ) ) {

				if ( Attributes.VendorID == vendor_id && Attributes.ProductID == product_id ) {

					if ( HIDP_STATUS_SUCCESS == GetDeviceCapabilities( hDevHandle ) ) {
						bDevDetected = TRUE;
					} // End of if ( HIDP_STATUS_SUCCESS == GetDeviceCapabilities( hDevHandle ) )

				} else {
					CloseHandle( hDevHandle );
				} // End of if (Attributes.VendorID == RS_VID && Attributes.ProductID == RS_PID)

			} else {
				CloseHandle( hDevHandle );
			} // End of if ( HidD_GetAttributes( hDevHandle, &Attributes ) )

			free(detailData);
		} else {
			LastDevice=TRUE;
		}  //if (Result != 0)

		MemberIndex++;
	} while ( (LastDevice == FALSE) && (bDevDetected == FALSE) ); //End of do

	if ( bDevDetected == FALSE ) {
		hDevHandle = INVALID_HANDLE_VALUE;
	} // End of (bDevDetected == FALSE)

	SetupDiDestroyDeviceInfoList(hDevInfo);

	return hDevHandle;
}

void __declspec(dllexport) __stdcall ReadReport(HANDLE handle,unsigned char *InputReport,int *len)
{
	ReadFile(handle,InputReport,Capabilities.InputReportByteLength,len,NULL);
}

void __declspec(dllexport) __stdcall WriteReport(HANDLE handle , unsigned char *OutputReport, int *len)
{
	WriteFile(handle,OutputReport,Capabilities.OutputReportByteLength,len,NULL);
}

void __declspec(dllexport) __stdcall CloseHidHandle( HANDLE handle )
{
	CloseHandle( handle );
}

