#include <windows.h> 
#include <process.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include <math.h>
#include "SDL/SDL.h"
#include "SDL/SDL_opengl.h"

#define ACC_GAIN 26

#define FUNC __declspec(dllimport) __stdcall
extern "C" HANDLE FUNC OpenHidHandle(unsigned short vendor_id, unsigned short product_id);
extern "C" void FUNC ReadReport(HANDLE handle,unsigned char *InputReport,int *len);
extern "C" void FUNC WriteReport(HANDLE handle,unsigned char *OutputReport, int *len);
extern "C" void FUNC CloseHidHandle(HANDLE handle);

HANDLE hRsDevHandle;

const USHORT VID = 0x057e; // Nintendo (?)
const USHORT PID = 0x0306; // Wii-Remote (?)

#define MAXREPORTSIZE 256
int		InputLength,OutputLength;
unsigned char	InputReport[MAXREPORTSIZE];
unsigned char	OutputReport[MAXREPORTSIZE];

unsigned char	button1,button2;
unsigned char	Ax,Ay,Az;
unsigned char	wii_remote_loop_flag;
unsigned char	wii_remote_in_use;

void Wii_Remote_Input(void);
void Wii_Remote_mode_0x31(void);
int Wii_Remote_check(void);

int HandleEvent(SDL_Event *event)
{
	int done;
	done=0;
	switch( event->type ) {
		case SDL_KEYDOWN:
			//printf("key '%s' pressed\n", SDL_GetKeyName(event->key.keysym.sym));
			if ( event->key.keysym.sym == SDLK_ESCAPE ) { done=1; }
			break;
		case SDL_QUIT:
			done=1;
			break;
	}
	return done;
}

int Do_sdl_event()
{
	int done;
	done=0;
	SDL_Event event;
	while( SDL_PollEvent(&event) ) {
		done=HandleEvent(&event);
	}
	return done;
}

int RunGLTest()
{
	Uint32 video_flags;
	int value;
	int bpp = 0;
	int rgb_size[3];
	int w = 640;
	int h = 480;
	int done = 0;
	GLenum gl_error;
	char* sdl_error;
	float cube[8][3]= {
		{ 0.5,  0.4, -1.5}, { 0.5, -0.4, -1.5}, {-0.5, -0.4, -1.5}, {-0.5,  0.4, -1.5},
		{-0.5,  0.4,  1.5}, { 0.5,  0.4,  1.5}, { 0.5, -0.4,  1.5}, {-0.5, -0.4,  1.5}  };
	
	putenv("SDL_VIDEODRIVER=directx");
	if( SDL_Init( SDL_INIT_VIDEO | SDL_INIT_JOYSTICK) < 0 ) {
		fprintf(stderr,"Couldn't initialize SDL: %s\n",SDL_GetError());
		exit( 1 );
	}
	
	SDL_ShowCursor(SDL_DISABLE);

	video_flags = SDL_OPENGL;
	if ( SDL_GetVideoInfo()->vfmt->BitsPerPixel <= 8 ) { bpp=8; } else { bpp=16; }
	switch (bpp) {
		case 8:  rgb_size[0]=3; rgb_size[1]=3; rgb_size[2]=2; break;
		case 16: rgb_size[0]=5; rgb_size[1]=5; rgb_size[2]=5; break;
		default: rgb_size[0]=8; rgb_size[1]=8; rgb_size[2]=8; break;
	}
	SDL_GL_SetAttribute( SDL_GL_RED_SIZE,   rgb_size[0] );
	SDL_GL_SetAttribute( SDL_GL_GREEN_SIZE, rgb_size[1] );
	SDL_GL_SetAttribute( SDL_GL_BLUE_SIZE,  rgb_size[2] );
	SDL_GL_SetAttribute( SDL_GL_DEPTH_SIZE, 16 );
	SDL_GL_SetAttribute( SDL_GL_DOUBLEBUFFER, 1 );
	SDL_GL_SetAttribute( SDL_GL_MULTISAMPLEBUFFERS, 1 );
	SDL_GL_SetAttribute( SDL_GL_ACCELERATED_VISUAL, 1 );
	SDL_GL_SetAttribute( SDL_GL_SWAP_CONTROL, 1 );
	if ( SDL_SetVideoMode( w, h, bpp, video_flags ) == NULL ) {
		fprintf(stderr, "Couldn't set GL mode: %s\n", SDL_GetError());
		SDL_Quit(); exit(1);
	}

	SDL_WM_SetCaption( "Wii Remote test", "testgl" );

	glViewport( 0, 0, w, h );
	glMatrixMode( GL_PROJECTION );
	glLoadIdentity( );
	glOrtho( -2.0, 2.0, -2.0, 2.0, -20.0, 20.0 );
	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity( );
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
	glShadeModel(GL_SMOOTH);

	while( !done ) {
		float ta1,ta2;
		float jx,jy;
		static float tl1,tl2;
		static unsigned char offset1=0x80;
		static unsigned char offset2=0x80;
		
		Wii_Remote_Input(); // Wii Remote
		
		if (button2==0x80) { break; }  // Home Key  to Quit
		
		if (button2==0x08) {   // [A] Key
			offset1 = Ax;
			offset2 = Ay;
		}
		
		ta1 = (double)(Ax - offset1) / ACC_GAIN;
		ta2 = (double)(Ay - offset2) / ACC_GAIN;
		
		tl1 = (tl1*2 + ta1 ) /3;
		tl2 = (tl2*2 + ta2 ) /3;
		
		if (tl1>1.0) { tl1=1.0; }
		if (tl2>1.0) { tl2=1.0; }
		if (tl1<-1.0) { tl1=-1.0; }
		if (tl2<-1.0) { tl2=-1.0; }
		jx = asin(tl1)*180/3.14159265;
		jy = asin(tl2)*180/3.14159265;
		
		glClearColor( 0.0, 0.0, 0.0, 1.0 );
		glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		
		glMatrixMode(GL_MODELVIEW);
		
		glLoadIdentity(); // Matrix reset
		
		// Rotation
		glRotatef(5.0 , 0, 1.0, 0);
		//glRotatef(2.0 , 1.0, 0, 0);
		glRotatef(-jy, 1.0, 0, 0);
		glRotatef(-jx, 0, 0, 1.0);
	
		// draw CUBE
		glBegin( GL_QUADS );
		 glColor3f(1.0, 1.0, 1.0);
		 glVertex3fv(cube[0]);glVertex3fv(cube[1]);glVertex3fv(cube[2]);glVertex3fv(cube[3]);
		 glColor3f(0.9, 0.9, 0.9);
		 glVertex3fv(cube[3]);glVertex3fv(cube[4]);glVertex3fv(cube[7]);glVertex3fv(cube[2]);
		 glColor3f(0.8, 0.8, 0.8);
		 glVertex3fv(cube[0]);glVertex3fv(cube[5]);glVertex3fv(cube[6]);glVertex3fv(cube[1]);
		 glColor3f(0.7, 0.7, 0.7);
		 glVertex3fv(cube[5]);glVertex3fv(cube[4]);glVertex3fv(cube[7]);glVertex3fv(cube[6]);
		 glColor3f(1.0, 1.0, 1.0);
		 glVertex3fv(cube[5]);glVertex3fv(cube[0]);glVertex3fv(cube[3]);glVertex3fv(cube[4]);
		 glColor3f(0.8, 0.8, 0.8);
		 glVertex3fv(cube[6]);glVertex3fv(cube[1]);glVertex3fv(cube[2]);glVertex3fv(cube[7]);
		glEnd( );
		
		SDL_GL_SwapBuffers( );

		// GL error check ,  SDL error check
		gl_error = glGetError( );   sdl_error = SDL_GetError( );
		if( gl_error != GL_NO_ERROR ) {
			fprintf( stderr, "testgl: OpenGL error: %d\n", gl_error );
		}
		if( sdl_error[0] != '\0' ) {
			fprintf(stderr, "testgl: SDL error '%s'\n", sdl_error); SDL_ClearError();
		}
		
		// SDL event process
		done=Do_sdl_event();
		
		// wait
		SDL_Delay(10);
	}
	
	SDL_Quit();
	return 0;
}

void Sleep2(int msec)
{
	LARGE_INTEGER f;
	LARGE_INTEGER t1,t2;
	double t;
	QueryPerformanceFrequency(&f);
	QueryPerformanceCounter(&t1);
	while (1) {
		QueryPerformanceCounter(&t2);
		t = (double)t2.QuadPart - (double)t1.QuadPart;
		t /= (double)f.QuadPart;
		t *= 1000;
		if (t>(double)msec) { return; }
	}
}

void Report_0x11(unsigned char data)
{
	OutputReport[0]=0x11; // Report ID
	OutputReport[1]=data;
	WriteReport( hRsDevHandle , OutputReport , &OutputLength);
}

void Report_0x12(unsigned char data1,unsigned char data2)
{
	OutputReport[0]=0x12; // Report ID
	OutputReport[1]=data1;
	OutputReport[2]=data2;
	WriteReport( hRsDevHandle , OutputReport , &OutputLength);
}

void Report_0x13(unsigned char data)
{
	OutputReport[0]=0x13; // Report ID
	OutputReport[1]=data;
	WriteReport( hRsDevHandle , OutputReport , &OutputLength);
}

void Wii_Remote_mode_0x31(void)
{
	// Set Report Type
	Report_0x12(0x00,0x31);  // Acc Sensor + button  Report Mode
}

void Wii_Remote_Input(void)
{
	ReadReport( hRsDevHandle , InputReport, &InputLength);
	if ( InputReport[0]==0x30 ) {
		button1=InputReport[1]; button2=InputReport[2];
	}
	if ( InputReport[0]==0x31 ) {
		button1=InputReport[1]; button2=InputReport[2];
		Ax = InputReport[3];
		Ay = InputReport[4];
		Az = InputReport[5];
	}
}

void Wii_Remote_Input_Main(void *)
{
	// wii remote input thread
	while (wii_remote_loop_flag) {
		wii_remote_in_use=1;
		Wii_Remote_Input();
		Sleep(100);
	}
	wii_remote_in_use=0;
	return;
}

uintptr_t wii_th;

int Wii_Remote_check(void)
{
	Ax=0;
	wii_remote_loop_flag=1;
	wii_th = _beginthread( Wii_Remote_Input_Main , 0 , NULL );
	Sleep2(100);
	wii_remote_loop_flag=0;
	return (Ax!=0);
}

void Stop_Wii_remote_th(void)
{
	if (wii_remote_in_use==1) {
		TerminateThread( (HANDLE)wii_th , -1); // kill thread  if it stopped
	}
}


int main( int argc, char *argv[])
{ 
	int i;
	
	hRsDevHandle = OpenHidHandle(VID,PID);
	if ( hRsDevHandle == INVALID_HANDLE_VALUE) {
		MessageBox(0,"Wii-Remote not found.",0,0);
		return 1;
	}
	
	Wii_Remote_mode_0x31();
	if ( Wii_Remote_check() ) {
	
		Report_0x13(0x01);  //Rumble ON
		Sleep2(200); // wait
	
		// LED command stops rumble(?)
		Report_0x11(0xF0); // LEDs on
		
		Report_0x13(0x00); //Rumble OFF
		Sleep2(200); // wait
		
		Report_0x11(0x00); // LEDs off
		
		RunGLTest(); // Start Graphic Display
		
	} else {
		
		MessageBox(0,"Wii-Remote cannot open.",0,0);
		Stop_Wii_remote_th();
	}
	CloseHidHandle( hRsDevHandle );
	return 0;
} 
