#include "wm_base.h"

wm_base::wm_base(void)
{
	hDeviceInfo = 0;
	bDeviceDetected=FALSE;
}

wm_base::~wm_base(void)
{
}

void wm_base::ReadReport(HANDLE h,unsigned char *Input,DWORD *len)
{
	printf("[R]%x",Input[0]);
	ReadFile(h,Input,Caps.InputReportByteLength,len,NULL);
}


///mamma
void wm_base::WriteReport(HANDLE h , unsigned char *Output, DWORD *len)
{
	printf("[W]%x",Output[0]);
	WriteFile(h,Output,Caps.OutputReportByteLength,len,NULL);
}

///mamma
void wm_base::Sleep(int msec)
{
	LARGE_INTEGER f;
	LARGE_INTEGER t1,t2;
	double t;
	QueryPerformanceFrequency(&f);
	QueryPerformanceCounter(&t1);
	while (1) {
		QueryPerformanceCounter(&t2);
		t = (double)t2.QuadPart - (double)t1.QuadPart;
		t /= (double)f.QuadPart;
		t *= 1000;
		if (t>(double)msec) { return; }
	}
}

void wm_base::Report_0x12(unsigned char data1,unsigned char data2)
{

	Input[0]=0x12;
	Input[1]=data1;
	Input[2]=data2;
	WriteReport( hWiiRemoteHID , Output , &dwOutputLen);
}

void wm_base::Report_0x13(unsigned char data)
{
	Output[0]=0x13;
	Output[1]=data;
	WriteReport( hWiiRemoteHID , Output , &dwOutputLen);
}


void wm_base::Wii_Remote_Input(void)
{
	ReadReport( hWiiRemoteHID , Input, &dwInputLen);
	if ( Input[0]==0x30 ) {
		button1=Input[1]; button2=Input[2];
	}
	if ( Input[0]==0x31 ) {
		button1=Input[1]; button2=Input[2];
		Ax = Input[3];
		Ay = Input[4];
		Az = Input[5];
	} 
	printf("Wii_Remote_Input[0]=[%c]\n",Input[0]);
}

/*
int wm_base::Wii_Remote_check(void)
{
	int Ax;
	Ax=0;
	wii_remote_loop_flag=1;
//	wii_th = _beginthread(Wii_Remote_Input_Main , 0 , NULL );
//	wii_th = (HANDLE)_beginthreadex(NULL,0, Wii_Remote_Input_Main ,this, 0 , NULL );
	Sleep(1000);
	wii_remote_loop_flag=0;
	return (Ax!=0);
}
*/


int	wm_base::Init(void) {
	fprintf(stderr,"Init()\n");

	hWiiRemoteHID = OpenWiiRemoteHID();
	if ( hWiiRemoteHID == INVALID_HANDLE_VALUE) {
		MessageBox(0,L"OpenWiiRemoteHID() failed.",0,0);
		return 0;	//fail
	}

	return 1; //success
}

NTSTATUS wm_base::GetDeviceCapabilities( HANDLE hWiiRemoteHID ) {
	PHIDP_PREPARSED_DATA PreparsedData;
	NTSTATUS Result = HIDP_STATUS_INVALID_PREPARSED_DATA;

	if ( HidD_GetPreparsedData( hWiiRemoteHID, &PreparsedData ) ) {
		Result = HidP_GetCaps( PreparsedData, &Caps );
		HidD_FreePreparsedData( PreparsedData );
	}

	return Result;
}

void wm_base::CloseWiiRemoteHID( HANDLE handle )
{
	CloseHandle( handle );
}


HANDLE wm_base::OpenWiiRemoteHID(void) {
//	LONG iHIDs;
	DWORD indexHID = 0;	
	BOOL bEndofDeviceList = FALSE;
	BOOL bDeviceDetected = FALSE; 
	PSP_DEVICE_INTERFACE_DETAIL_DATA DeviceDetail = NULL;
	DWORD size = 0;
	DWORD RequiredSize;
	HIDD_ATTRIBUTES Attributes;



	HidD_GetHidGuid( &guidHID );
	hDeviceInfo = SetupDiGetClassDevs(
		(LPGUID)&guidHID, NULL, 
		(HWND)NULL, 
		DIGCF_INTERFACEDEVICE | DIGCF_PRESENT 
	);
	if ( 0 == hDeviceInfo ) {
		return INVALID_HANDLE_VALUE;	//�f�o�C�X���擾���s
	}
	do {
		bDeviceDetected=FALSE;
		//HID�C���^�t�F�[�X���
		deviceInfoData.cbSize = sizeof(SP_DEVICE_INTERFACE_DATA);
		if ( SetupDiEnumDeviceInterfaces 
			(hDeviceInfo, 
			NULL, 
			&guidHID, 
			indexHID, 
			&deviceInfoData)!=0 ) {
		    printf("[%d] HID found.\n",indexHID);

			//�񋓂���HID�̏ڍׂ��擾
			SetupDiGetDeviceInterfaceDetail(hDeviceInfo, 
				&deviceInfoData, NULL, 0, &size, 	NULL) ;
		    DeviceDetail = (PSP_DEVICE_INTERFACE_DETAIL_DATA)malloc(size);
			DeviceDetail -> cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);
			printf("HID detail size =%d.\n",DeviceDetail->cbSize);

			SetupDiGetDeviceInterfaceDetail (hDeviceInfo, 
				&deviceInfoData, DeviceDetail, size, &RequiredSize, NULL);
			
			hWiiRemoteHID = CreateFile 
				(DeviceDetail->DevicePath, 
				GENERIC_READ|GENERIC_WRITE, 
				FILE_SHARE_READ|FILE_SHARE_WRITE, 
				(LPSECURITY_ATTRIBUTES)NULL,
				OPEN_EXISTING, 
				0, 
				NULL);
			bDeviceDetected = FALSE;
			Attributes.Size = sizeof(Attributes);
			if ( HidD_GetAttributes( hWiiRemoteHID, &Attributes ) ) {
			 if ( Attributes.VendorID == 0x057e && Attributes.ProductID == 0x0306 ) {
			  if ( HIDP_STATUS_SUCCESS == GetDeviceCapabilities( hWiiRemoteHID ) ) {
			   printf(" WiiRemote found.[V=0x%04d,P=0x%04d]\n",Attributes.VendorID,Attributes.ProductID);
			   bDeviceDetected = TRUE;
			  } else {
				  printf(" GetDeviceCapabilities() failed.\n ");
			  }	
			 } else {
				 printf(" It didn't match with WiiRemote.[V=0x%04d,P=0x%04d]\n",Attributes.VendorID,Attributes.ProductID);
				 CloseHandle( hWiiRemoteHID );
			 }
			} else {
				printf(" HidD_GetAttributes() failed.\n");
				CloseHandle( hWiiRemoteHID );
			} 
			free(DeviceDetail);
		} else {
			bEndofDeviceList = TRUE;
		}
		
		indexHID++;
	} while ( (bEndofDeviceList == FALSE) && (bDeviceDetected == FALSE) );

	if ( bDeviceDetected == FALSE ) {
        printf("Finally, I couldn't find any WiiRemote.\n");
		hWiiRemoteHID = INVALID_HANDLE_VALUE;
	} else {
        printf("Yes, I found a WiiRemote.\n");
	}

	SetupDiDestroyDeviceInfoList(hDeviceInfo);
	return hWiiRemoteHID;

}

int	wm_base::SetRumble(int rumble){
	static long rumble_time=0;
	rumble_time += rumble;
	printf("rumble_time=%d\n",rumble_time);
	bRumble = rumble_time >0 ? true : false;
	rumble_time--;
	rumble_time <=0 ? 0 : rumble_time;
	return rumble_time;
}

