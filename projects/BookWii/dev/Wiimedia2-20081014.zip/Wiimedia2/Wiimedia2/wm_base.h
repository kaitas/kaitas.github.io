#ifndef _INC_WMBASE
#define _INC_WMBASE

#pragma once
#include <windows.h> 
#include <process.h>
#include <string.h> 
#include <setupapi.h>
#include <math.h> 
#include "stdio.h"
extern "C" {
#include "hidsdi.h"  //C:\WINDDK\3790.1830\inc\wxp
}
# pragma comment(lib, "setupapi.lib")	
# pragma comment(lib, "hid.lib")

#define MAXREPORTSIZE 256			///mamma

class wm_base
{
public:
	wm_base(void);
	~wm_base(void);
	int	Init(void);
	HANDLE OpenWiiRemoteHID(void);
	void CloseWiiRemoteHID( HANDLE handle );

	void Report_0x12(unsigned char data1,unsigned char data2);
	void Report_0x13(unsigned char data);
	void ReadReport(HANDLE h,unsigned char *Input,DWORD *len);
	void WriteReport(HANDLE handle , unsigned char *Output, DWORD *len);
//original func
	int	SetRumble(int rumble);

///mamma-func
//	int Wii_Remote_check(void);
	void Wii_Remote_Input(void);
	void Sleep(int msec);

	HANDLE hWiiRemoteHID;
	GUID guidHID;
	HDEVINFO hDeviceInfo;	
	SP_DEVICE_INTERFACE_DATA deviceInfoData;
//original value
	bool bRumble;

///mamma
	bool bDeviceDetected;
	DWORD			dwInputLen,dwOutputLen;
	unsigned char	Input[MAXREPORTSIZE];
	unsigned char	Output[MAXREPORTSIZE];
	HIDP_CAPS Caps;
	unsigned char	wii_remote_loop_flag;
	unsigned char	wii_remote_in_use;

	unsigned char	button1,button2;
	unsigned char	Ax,Ay,Az;
	uintptr_t wii_th;

	NTSTATUS GetDeviceCapabilities( HANDLE hWiiRemoteHID );


//void   CloseHidHandle(HANDLE handle);
//NTSTATUS GetDeviceCapabilities( HANDLE );


};
#endif // _INC_WMBASE

