// HelloWiimedia.cpp : �R���\�[�� �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//

#include "stdafx.h"



int _tmain(int argc, _TCHAR* argv[])
{
	unsigned char	WriteBuffer[MAXREPORTSIZE], In[MAXREPORTSIZE];

	DWORD written;
	bool One, Two, A, B, Minus, Plus, Home, Up, Down, Left, Right;

	wm_base w;
	if (w.Init()) {
		printf("Init success");

	WriteBuffer[0]=0x12;
	WriteBuffer[1]=0x00;
	WriteBuffer[2]=0x31;
	WriteFile( w.hWiiRemoteHID, WriteBuffer ,w.Caps.OutputReportByteLength,&written,NULL);
	printf("caps[O:%d,I:%d]\n",w.Caps.OutputReportByteLength,w.Caps.InputReportByteLength);
	printf("written=%d\n",written);
	ReadFile(  w.hWiiRemoteHID, In, w.Caps.InputReportByteLength, &written, NULL );
	printf("received=%d\n",written);


	while (true) {
		ReadFile(  w.hWiiRemoteHID, In, w.Caps.InputReportByteLength, &written, NULL );
		printf("x=%4d y=%4d z=%4d\n",In[3],In[4],In[5]);


		Left=  In[1] & 0x0001 ? true : false ;
		Right= In[1] & 0x0002 ? true : false ;
		Down=  In[1] & 0x0004 ? true : false ;
		Up  =  In[1] & 0x0008 ? true : false ;
		Plus=  In[1] & 0x0010 ? true : false ;
		Two =  In[2] & 0x0001 ? true : false ;
		One =  In[2] & 0x0002 ? true : false ;
		B   =  In[2] & 0x0004 ? true : false ;
		A   =  In[2] & 0x0008 ? true : false ;
		Minus= In[2] & 0x0010 ? true : false ;
		Home=  In[2] & 0x0080 ? true : false ;

		if (Home) {break;}

		written = 2;
		if (One) {
			WriteBuffer[0] = 0x13;
			WriteBuffer[1] = 0x01;
			WriteFile( w.hWiiRemoteHID, WriteBuffer ,w.Caps.OutputReportByteLength,&written,NULL);
			printf("[1]\n");
		} else {
			WriteBuffer[0] = 0x13;
			WriteBuffer[1] = 0x00;
			WriteFile( w.hWiiRemoteHID, WriteBuffer ,w.Caps.OutputReportByteLength,&written,NULL);
		}
/*
		if (Minus) {
			WriteBuffer[0] = 0x11;
			WriteBuffer[0] = 0xF0;
			WriteFile( w.hWiiRemoteHID, WriteBuffer ,w.Caps.OutputReportByteLength,&written,NULL);
			printf("[-]\n");
		}
*/	
	}

//		w.SetMode_0x31();
//		if ( w.Wii_Remote_check() ) {
//		w.Report_0x13(0x01);  //Rumble ON
//		w.Sleep(200);

/*
		// LED command stops rumble(?)
		Report_0x11(0xF0); // LEDs on
		
		Report_0x13(0x00); //Rumble OFF
		Sleep2(200); // wait
		
		Report_0x11(0x00); // LEDs off
		
		RunGLTest(); // Start Graphic Display
		} else {
			printf("Check failed.");		
		}
*/		
	} else {
		printf("Init failed");
//			MessageBox(0,L"WiiRemote cannot open.",0,0);
//		Stop_Wii_remote_th();
	}
	w.CloseWiiRemoteHID( w.hWiiRemoteHID );

	return 0;
} 

