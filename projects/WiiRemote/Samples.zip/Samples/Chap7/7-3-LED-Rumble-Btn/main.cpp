#include "../../wiimote.h"
int _tmain(int argc, _TCHAR* argv[])
{
  wiimote cWiiRemote;
  _tprintf(_T("Hello, WiiRemote!\n"));
  _tprintf(_T("contains WiiYourself! wiimote code by gl.tter\nhttp://gl.tter.org\n")); //���C�Z���X�\��
  //WiiRemote�Ɛڑ�
  while(!cWiiRemote.Connect(wiimote::FIRST_AVAILABLE)) {
    _tprintf(_T("Connecting to a WiiRemote.\n"));
    Sleep(1000);
  }
  _tprintf(_T("connected.\n"));
  //LED��S�_��
  cWiiRemote.SetLEDs(0x0f);
  Sleep(1000);
  cWiiRemote.SetReportType(wiimote::IN_BUTTONS);
  //Home�{�^���ŏI��
  while(!cWiiRemote.Button.Home()) {
    while(cWiiRemote.RefreshState()==NO_CHANGE) {
      Sleep(1);
    }
    cWiiRemote.SetRumble(cWiiRemote.Button.B());
  }
  //�ؒf�E�I��
  cWiiRemote.Disconnect();
  _tprintf(_T("Disconnected.\n"));
  return 0;
}
