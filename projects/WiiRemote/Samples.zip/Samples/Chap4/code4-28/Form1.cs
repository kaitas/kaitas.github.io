﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WiimoteLib;		//WimoteLibの使用を宣言


namespace code4_28 {
	public partial class Form1 : Form {

		Wiimote wm = new Wiimote();		//Wiimoteの宣言

		public Form1() {
			Control.CheckForIllegalCrossThreadCalls = false; //おまじない フォームのアクセスを許可する
			InitializeComponent();
			wm.WiimoteChanged += wm_WiimoteChanged; //イベント関数の登録
			wm.Connect(); //WiiRemoteと接続
		}

		//Wiiリモコンの値が変化したときに呼ばれる関数
		void wm_WiimoteChanged(object sender, WiimoteChangedEventArgs args) {
			WiimoteState ws = args.WiimoteState; //WiimoteStateの値を取得

			//Aボタンが押されたらメモ帳を起動
			if (ws.ButtonState.A == true) {
				System.Diagnostics.Process.Start("notepad.exe");	//メモ帳を起動
			}

			//Bボタンが押されたら電卓を起動
			if (ws.ButtonState.B == true) {
				System.Diagnostics.Process.Start("calc.exe");		//電卓を起動
			}

			//HOMEボタンが押されたらこのアプリを終了
			if (ws.ButtonState.Home == true) {
				Environment.Exit(0);
			}
		}
	}
}
