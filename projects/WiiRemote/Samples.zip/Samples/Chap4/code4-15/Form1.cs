﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WiimoteLib;	//WimoteLibの使用を宣言

namespace code4_15 {
	public partial class Form1 : Form {

		Wiimote wm = new Wiimote(); //Wiimoteの宣言
		int count = 0;				//int型 count宣言

		public Form1() {
			InitializeComponent();
			wm.Connect(); //Wiimoteの接続
		}

		private void button1_Click(object sender, EventArgs e) {
			this.button1.Text = "wm.SetLEDs(" + count + ")を表示中";	//button1のTextを変更
			wm.SetLEDs(count);											//countをLEDの引数に指定
			count++;													//countを１ずつ増加
		}
	}
}
