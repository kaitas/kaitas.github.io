﻿//不要なusing宣言は整理してかまいません
using System;
using System.Windows.Forms;
using System.Drawing;	//描画のために必要
using WiimoteLib;		//WimoteLibの使用を宣言

namespace code4_57{
	public partial class Form1 : Form {

		Wiimote wm = new Wiimote();		//Wiimoteの宣言


		public Form1() {
			InitializeComponent();

			//他スレッドからのコントロール呼び出し許可
			Control.CheckForIllegalCrossThreadCalls = false;
		}

		//接続ボタンが押されたら
		private void button1_Click(object sender, EventArgs e) {
			wm.Connect(); //Wiimoteの接続
			wm.WiimoteChanged += wm_WiimoteChanged;					//イベント関数の登録
			wm.SetReportType(InputReport.IRExtensionAccel, true);	//レポートタイプの設定
		}

		//切断ボタンが押されたら
		private void button2_Click(object sender, EventArgs e) {
			wm.WiimoteChanged -= wm_WiimoteChanged; //イベント関数の登録解除
			wm.Disconnect();	//Wiimote切断
			wm.Dispose();		//オブジェクトの破棄
		}

		//Wiiリモコンの値が変化する度に呼ばれる関数
		//WiiRemoteの状態が変化したときに呼ばれる関数
		void wm_WiimoteChanged(object sender, WiimoteChangedEventArgs args) {
			WiimoteState ws = args.WiimoteState; //WiimoteStateの値を取得
			DrawForms(ws); //フォーム描写関数へ
		}

		public void DrawForms(WiimoteState ws) {
			Graphics g =this.pictureBox1.CreateGraphics(); //グラフィックス取得

			g.Clear(Color.Black); //画面を黒色にクリア
	
			//もし赤外線を１つ発見したら
			if (ws.IRState.IRSensors[0].Found) {
				//赤色でマーカを描写
				g.FillEllipse(Brushes.Red,
				ws.IRState.IRSensors[0].Position.X * 200, 
				ws.IRState.IRSensors[0].Position.Y * 200, 10, 10);
			}

			//もし赤外線を２つ発見したら
			if (ws.IRState.IRSensors[1].Found) {
				//青色でマーカを描写
				g.FillEllipse(Brushes.Blue,
				ws.IRState.IRSensors[1].Position.X * 200,
				ws.IRState.IRSensors[1].Position.Y * 200, 10, 10);
			}
			//もし赤外線を３つ発見したら
			if (ws.IRState.IRSensors[2].Found) {
				//黄色でマーカを描写
				g.FillEllipse(Brushes.Yellow,
				ws.IRState.IRSensors[2].Position.X * 200,
				ws.IRState.IRSensors[2].Position.Y * 200, 10, 10);
			}
			//もし赤外線を４つ発見したら
			if (ws.IRState.IRSensors[3].Found) {
				//緑色でマーカを描写
				g.FillEllipse(Brushes.Green,
				ws.IRState.IRSensors[3].Position.X * 200,
				ws.IRState.IRSensors[3].Position.Y * 200, 10, 10);
			}
			g.Dispose();//グラフィックスの解放
		}

	}
}
