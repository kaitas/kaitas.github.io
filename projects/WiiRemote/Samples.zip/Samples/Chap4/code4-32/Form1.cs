﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WiimoteLib;		//WimoteLibの使用を宣言


namespace code4_32 {
	public partial class Form1 : Form {

		Wiimote wm = new Wiimote();		//Wiimoteの宣言

		public Form1() {
			Control.CheckForIllegalCrossThreadCalls = false; //おまじない フォームのアクセスを許可する
			InitializeComponent();

			wm.WiimoteChanged += wm_WiimoteChanged; //イベント関数の登録
			wm.SetReportType(InputReport.ButtonsAccel, true); //レポートタイプの設定
			wm.Connect(); //WiiRemoteと接続
		}

		//Wiiリモコンの値が変化したときに呼ばれる関数
		void wm_WiimoteChanged(object sender, WiimoteChangedEventArgs args) {
			WiimoteState ws = args.WiimoteState; //WiimoteStateの値を取得
			this.DrawForms(ws); //フォーム描画関数へ
		}

		//フォーム描画関数
		public void DrawForms(WiimoteState ws) {
			this.label1.Text = "X軸:" + (ws.AccelState.Values.X);	//label1のTextに加速度センサX軸の状態を表示
			this.label2.Text = "Y軸:" + (ws.AccelState.Values.Y);	//label2のTextに加速度センサY軸の状態を表示
			this.label3.Text = "Z軸:" + (ws.AccelState.Values.Z);	//label3のTextに加速度センサZ軸の状態を表示
		}
	}
}
