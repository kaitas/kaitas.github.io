﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WiimoteLib;		//WimoteLibの使用を宣言
using System.Media;		//System.Mediaの宣言

namespace code4_40 {
	public partial class Form1 : Form {

		Wiimote wm = new Wiimote();		//Wiimoteの宣言
		string path = null;				//Wavファイル名
		SoundPlayer wavePlayer;			//SoundPlayerを宣言


		public Form1() {
			InitializeComponent();

			wm.WiimoteChanged += wm_WiimoteChanged;				//イベント関数の登録
			wm.SetReportType(InputReport.ButtonsAccel, true);	//レポートタイプの設定
			wm.Connect();										//WiiRemoteの接続

			path = @"C:\WINDOWS\Media\tada.wav";				//再生するWAVファイルを指定
			wavePlayer = new SoundPlayer(path);					//プレイヤーにWAVファイルを渡す
		}

		//Wiiリモコンの値が変化したときに呼ばれる関数
		void wm_WiimoteChanged(object sender, WiimoteChangedEventArgs args) {
			WiimoteState ws = args.WiimoteState; //WiimoteStateの値を取得

			//WAVファイルが読み込まれているか確認
			if (this.path != null) {
				float AX = Math.Abs(ws.AccelState.Values.X); //X軸の絶対値
				float AY = Math.Abs(ws.AccelState.Values.Y); //Y軸の絶対値
				float AZ = Math.Abs(ws.AccelState.Values.Z); //Z軸の絶対値
				//X,Y,Z軸の加速度センサーの絶対値の合計が5を超える時に、振ったと判定
				if ((AX + AY + AZ) >= 5) {
					wavePlayer.PlaySync(); //音を鳴らす
				}
			}
		}

		
	}
}
